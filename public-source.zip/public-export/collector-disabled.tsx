// The public build has no collection controls or server endpoints.
export default function CollectorDisabled(_props: unknown){return null;}
