import {createRoot} from 'react-dom/client';
import Atlas from '../app/atlas';
import '../app/globals.css';

createRoot(document.getElementById('root')!).render(<Atlas publicMode/>);
