'use client';

import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {ArrowUpRight,Compass,MapPin,RotateCcw,Layers,LocateFixed} from 'lucide-react';
import type * as Leaflet from 'leaflet';
import 'leaflet/dist/leaflet.css';
import locationsData from './data/locations.json';
import type {CaseRecord} from './data/types';
import type {LocationRecord as Location} from './data/location-types';
import {groupLocations,locationLabel} from '../lib/map-model.mjs';
import './case-map.css';

type Group={key:string;location:Location;cases:CaseRecord[]};
const locations=locationsData as Record<string,Location>;
const year=(c:CaseRecord)=>c.periodYear||c.completedYear||c.openedYear||'-';
const precisionLabel=locationLabel;

export default function CaseMap({cases,onOpen}:{cases:CaseRecord[];onOpen:(c:CaseRecord)=>void}){
 const host=useRef<HTMLDivElement>(null);
 const map=useRef<Leaflet.Map|null>(null);
 const library=useRef<typeof Leaflet|null>(null);
 const fitOnResize=useRef<()=>void>(()=>{});
 const markers=useRef(new Map<string,Leaflet.Marker>());
 const [ready,setReady]=useState(false),[selectedId,setSelectedId]=useState<string|null>(null);
 const [mapError,setMapError]=useState(false),[tileError,setTileError]=useState(false);
 const {groups,missing}=useMemo(()=>groupLocations(cases,locations) as {groups:Group[];missing:CaseRecord[]},[cases]);
 const selected=cases.find(c=>c.id===selectedId);
 const selectedLocation=selected?locations[selected.id]:undefined;
 const selectedGroup=groups.find(g=>g.cases.some(c=>c.id===selectedId));
 const locatedCount=cases.length-missing.length;
 const facilityCount=groups.filter(g=>g.location.precision==='site').reduce((n,g)=>n+g.cases.length,0);
 const uncertainCount=cases.length-facilityCount;

 useEffect(()=>{
  let disposed=false;let observer:ResizeObserver|undefined;
  import('leaflet').then(L=>{
   if(disposed||!host.current)return;
   library.current=L;
   const m=L.map(host.current,{scrollWheelZoom:false,zoomControl:true,minZoom:5,maxZoom:18,attributionControl:true}).setView([36.2,127.8],7);
   map.current=m;
   m.zoomControl.setPosition('topright');
   m.zoomControl.getContainer()?.querySelector('.leaflet-control-zoom-in')?.setAttribute('aria-label','지도 확대');
   m.zoomControl.getContainer()?.querySelector('.leaflet-control-zoom-out')?.setAttribute('aria-label','지도 축소');
   let failures=0;
   L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
    maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors',
   }).on('tileerror',()=>{if(!disposed&&++failures>=3)setTileError(true)}).on('tileload',()=>{if(!disposed){failures=0;setTileError(false)}}).addTo(m);
   observer=new ResizeObserver(()=>{m.invalidateSize();fitOnResize.current()});observer.observe(host.current);
   setReady(true);
  }).catch(()=>{if(!disposed)setMapError(true)});
  return()=>{disposed=true;observer?.disconnect();map.current?.remove();map.current=null;library.current=null;markers.current.clear()};
 },[]);

 const fit=useCallback(()=>{
  const m=map.current,L=library.current;if(!m||!L)return;
  if(!groups.length){m.setView([36.2,127.8],7);return;}
  m.fitBounds(L.latLngBounds(groups.map(g=>[g.location.lat,g.location.lng] as [number,number])),{padding:[42,42],maxZoom:groups.length===1?(groups[0].location.precision==='site'?13:9):10,animate:false});
 },[groups]);
 fitOnResize.current=fit;

 useEffect(()=>{
  const m=map.current,L=library.current;if(!ready||!m||!L)return;
  const layer=L.layerGroup().addTo(m);markers.current.clear();
  for(const group of groups){
   const count=group.cases.length;
   const name=count===1?group.cases[0].title:`${group.location.label} · 사례 ${count}개`;
   const pin=L.divIcon({className:'case-map-marker '+group.location.precision,html:`<span>${count>1?count:'<i></i>'}</span>`,iconSize:[34,34],iconAnchor:[17,17]});
   const marker=L.marker([group.location.lat,group.location.lng],{icon:pin,title:`${name} · ${precisionLabel(group.location)}`,alt:name,keyboard:true}).addTo(layer);
   marker.on('click',()=>setSelectedId(group.cases[0].id));
   const tip=document.createElement('span');tip.textContent=name;marker.bindTooltip(tip,{direction:'top',offset:[0,-16]});
   const element=marker.getElement();if(element){element.setAttribute('role','button');element.setAttribute('aria-label',`${name} · ${precisionLabel(group.location)}`);}
   markers.current.set(group.key,marker);
  }
  setSelectedId(current=>cases.some(c=>c.id===current)?current:null);
  fit();
  return()=>{m.removeLayer(layer);markers.current.clear()};
 },[ready,groups,cases,fit]);

 useEffect(()=>{for(const [key,marker] of markers.current)marker.getElement()?.classList.toggle('is-selected',key===selectedGroup?.key)},[selectedGroup,ready]);

 function focus(item:CaseRecord){
  const group=groups.find(g=>g.cases.some(c=>c.id===item.id));
  if(!group){onOpen(item);return;}
  setSelectedId(item.id);map.current?.setView([group.location.lat,group.location.lng],group.location.precision==='site'?14:10,{animate:true});
 }

 return <section className="case-map-section" aria-label="참여설계 사례 위치 지도">
  <div className="location-coverage" aria-live="polite"><span>시설 위치 확인 <b>{facilityCount}건</b></span><span className={uncertainCount?'uncertain':''}>정확한 위치 미확인 <b>{uncertainCount}건</b></span></div><div className="case-map-top"><div className="map-legend"><span><i className="site-dot"/> 시설 위치</span><span><i className="municipality-dot"/> 시·군·구 대표 위치</span><span className="map-legend-count">숫자는 같은 위치의 사례 수</span></div><button className="map-fit" onClick={fit} disabled={!ready} aria-label="필터 결과 전체 위치 보기"><RotateCcw size={13}/> 전체 위치</button></div>
  <div className="case-map-workspace">
   <div className="case-map-canvas-wrap">
    <div ref={host} className="case-map-canvas" role="region" aria-label="대한민국 사례 지도. 확대·축소 버튼과 위치 표시를 선택하세요."/>
    {!ready&&!mapError&&<div className="map-loading" role="status"><Compass size={28}/><span>지도를 불러오고 있습니다.</span></div>}
    {(mapError||tileError)&&<div className="map-load-warning" role="status">{mapError?'지도를 불러오지 못했습니다.':'배경 지도를 불러오지 못했습니다.'} 아래 사례 목록으로 계속 탐색할 수 있습니다.</div>}
    <div className="map-canvas-caption"><span className="live-dot"/> {locatedCount}개 사례 위치 · 대한민국</div>
   </div>
   <aside className="map-case-panel" aria-label="지도 사례 목록">
    <div className="map-panel-heading"><div><span className="map-panel-eyebrow">SPACES ON THE MAP</span><h3>{selected?'선택한 공간':'지도 속 공간'} <span>{locatedCount}</span></h3></div><MapPin size={21}/></div>
    {selected&&selectedGroup&&selectedLocation?<div className="map-selected-card" aria-live="polite"><span className="map-selected-type">{selected.siteType} · {year(selected)}</span><h4>{selected.title}</h4><p>{selected.summary}</p><div className="map-location-note"><LocateFixed size={13}/><span>{precisionLabel(selectedLocation)}<small>{selectedLocation.address||selectedLocation.label}</small></span></div>{selectedLocation.precision==='municipality'&&<p className="map-accuracy-note">{selectedLocation.note||'정확한 시설 좌표는 미확인입니다. 표시점은 해당 행정구역의 대표 위치입니다.'}</p>}<a className="map-source-link" href={selectedLocation.sourceUrl} target="_blank" rel="noreferrer">주소·위치 근거 <ArrowUpRight size={12}/></a><button className="primary map-detail-button" onClick={()=>onOpen(selected)}>사례 상세 보기 <ArrowUpRight size={14}/></button>{selectedGroup.cases.length>1&&<div className="map-colocated"><b>같은 위치에 표시된 사례</b>{selectedGroup.cases.map(c=><button key={c.id} onClick={()=>setSelectedId(c.id)} aria-pressed={c.id===selectedId}>{c.title}</button>)}</div>}</div>:<p className="map-panel-intro">지도 위 표시나 아래 사례를 선택해<br/>이 공간을 만든 사람과 과정을 살펴보세요.</p>}
    <div className="map-result-list" aria-label="필터에 맞는 사례">
     {cases.length?cases.map((item,index)=>{const location=locations[item.id];const hasLocation=groups.some(g=>g.cases.some(c=>c.id===item.id));return <button key={item.id} className={'map-result '+(selectedId===item.id?'selected':'')} onClick={()=>focus(item)} aria-pressed={selectedId===item.id}><span className="map-result-number">{String(index+1).padStart(2,'0')}</span><span><strong>{item.title}</strong><small>{item.region} {item.city} · {year(item)}</small><em>{hasLocation?precisionLabel(location):'위치 미확인 · 상세 기록 보기'}</em></span><ArrowUpRight size={14}/></button>}):<div className="map-empty"><Layers size={25}/><p>이 조건의 사례가 없습니다.<br/>검색어나 필터를 바꿔보세요.</p></div>}
    </div>
   </aside>
  </div>
  <div className="map-footnote"><p>시설 위치는 해당 학교·공원·건물을 가리킵니다. 정확한 출입구나 내부 설계 대상의 경계는 별도 확인이 필요합니다. 점선 표시는 시설 좌표 미확인 사례의 시·군·구 대표점입니다.</p><span>{missing.length>0?`좌표 미확인 ${missing.length}건 · 목록에서 확인 가능`:`검색 결과 ${cases.length}건 모두 지도에 표시`}</span></div>
 </section>;
}
