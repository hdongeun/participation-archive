export type Person = {name:string;role:string};
export type CaseRecord = {
 fieldSources?:Record<string,string[]>;searchAliases?:string[];checkedAt?:string;
 id:string;title:string;country:string;region:string;city:string;siteType:string;subtype?:string;
 completedYear:number|null;completedDate:string|null;openedYear?:number|null;openedDate?:string|null;periodYear?:number;dateBasis?:string;datePrecision:string;organizer:string[];architects:Person[];contractors:string[];participants:Person[];
 participationMethods:string[];participationStages:string[];process:{date:string|null;title:string;description:string;sourceUrl:string}[];
 summary:string;evidence:{participation:string;built:string;date:string};evidenceSources?:{participation?:string;built?:string;date?:string};sources:{title:string;url:string;publisher:string;type:string}[];
 photos:{url?:string|null;sourceUrl:string;caption:string;credit:string;phase:string;license?:string|null}[];missingNotes:string|string[];
};
