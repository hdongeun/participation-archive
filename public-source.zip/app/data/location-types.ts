export type LocationSource={title:string;url:string;kind?:'address'|'coordinates'|'identity';evidence?:string};
export type LocationRecord={
 lat:number;lng:number;precision:'site'|'municipality';label:string;address?:string|null;
 sourceUrl:string;sourceTitle?:string;checkedAt:string;note?:string;sources?:LocationSource[];
 resolutionStatus?:'verified'|'address-only'|'unresolved';
};
