import {ArrowUpRight} from 'lucide-react';
import type {LocationRecord} from './data/location-types';
import {locationLabel} from '../lib/map-model.mjs';

const href=(value:string)=>{try{const u=new URL(value);return u.protocol==='https:'?u.href:'#'}catch{return '#'}};
const kindLabel={address:'주소',coordinates:'좌표',identity:'시설 식별'};
export default function LocationInfo({location:l}:{location?:LocationRecord}){
 return <section className="location-detail"><h3>지도 위치</h3>{l?<>
  <p><span className={'tag location-status '+(l.precision==='site'?'confirmed':'uncertain')}>{locationLabel(l)}</span> {l.label}</p>
  <dl className="location-address"><dt>시설 주소</dt><dd>{l.address||'-'}</dd><dt>표시 좌표</dt><dd>{l.lat.toFixed(6)}, {l.lng.toFixed(6)}{l.precision!=='site'&&<small>시·군·구 대표점 · 시설 좌표 아님</small>}</dd></dl>
  {l.note&&<p className="muted small">{l.note}</p>}
  <div className="location-links"><a href={`https://www.openstreetmap.org/?mlat=${l.lat}&mlon=${l.lng}#map=${l.precision==='site'?16:11}/${l.lat}/${l.lng}`} target="_blank" rel="noreferrer">큰 지도에서 보기 <ArrowUpRight size={13}/></a><small>위치 확인 {l.checkedAt}</small></div>
  <ol className="location-evidence">{(l.sources?.length?l.sources:[{title:l.sourceTitle||'위치 근거',url:l.sourceUrl}]).map((s,i)=><li key={s.url+'-'+i}><span>{s.kind?kindLabel[s.kind]:'위치 근거'}</span><div><a href={href(s.url)} target="_blank" rel="noreferrer">{s.title}<ArrowUpRight size={12}/></a>{s.evidence&&<p>{s.evidence}</p>}</div></li>)}</ol>
 </>:<p>위치 미확인 · -</p>}</section>;
}
